export const showToast = (obj) => async (dispatch) => {
  dispatch({ type: "SHOW_TOAST", payload: obj });
  setTimeout(() => {
    dispatch({ type: "SHOW_TOAST", payload: {} });
  }, 10);
};
