import React from "react";
import axios from "axios";
import { hideLoaderAction, showLoaderAction } from "./loaderAction";
import { Base_url, End_point } from "../../constants/Constants";
import { showToast } from "./toastAction";

const getAllAction = () => async (dispatch) => {
  dispatch(showLoaderAction());
  try {
    const res = await axios.get(Base_url + End_point.employee);
    console.log("resInactione", res);
    if (res.data.success) {
      if (res.data.data) {
        dispatch({
          type: "ALL",
          payload: res.data.data,
        });
      }
    }
  } catch (error) {
    console.error(error);
  }
  dispatch(hideLoaderAction());
};

const saveAction = (data, navigate) => async (dispatch) => {
  dispatch(showLoaderAction());
  try {
    const res = await axios.post(Base_url + End_point.employee, data);
    if (res.data.success) {
      if (res.data.data) {
        dispatch({
          type: "SAVE",
          payload: res.data.data,
        });
        dispatch(getAllAction());
        navigate("/");
        dispatch(showToast({ severity: "success", summary: res.data.message }));
      }
    }
  } catch (error) {
    console.error(error);
    dispatch(showToast({ severity: "error", summary: "Bad Request" }));
  }
  dispatch(hideLoaderAction());
};

const getOneAction = (id, returnData) => async (dispatch) => {
  dispatch(showLoaderAction());
  try {
    const res = await axios.get(Base_url + End_point.employee + id);
    if (res.data.success) {
      if (res.data.data) {
        if (returnData) {
          returnData(res.data.data);
        }
      }
    }
  } catch (error) {
    console.error(error);
    dispatch(showToast({ severity: "error", summary: "Bad Request" }));
  }
  dispatch(hideLoaderAction());
};

const updateAction = (id, data, navigate) => async (dispatch) => {
  dispatch(showLoaderAction());
  try {
    const res = await axios.put(Base_url + End_point.employee + id, data);
    if (res.data.success) {
      dispatch(getAllAction());
      navigate("/");
      dispatch(showToast({ severity: "success", summary: res.data.message }));
    }
  } catch (error) {
    console.error(error);
    dispatch(showToast({ severity: "error", summary: "Bad Request" }));
  }
  dispatch(hideLoaderAction());
};

const deleteAction = (id) => async (dispatch) => {
  dispatch(showLoaderAction());
  try {
    const res = await axios.delete(Base_url + End_point.employee + id);
    if (res.data.success) {
      dispatch(getAllAction());
      dispatch(showToast({ severity: "success", summary: res.data.message }));
    }
  } catch (error) {
    console.error(error);
    dispatch(showToast({ severity: "error", summary: "Bad Request" }));
  }
  dispatch(hideLoaderAction());
};

export { saveAction, getAllAction, getOneAction, updateAction, deleteAction };
