const intitalState = {
  toastInfo: {},
};

const toastReducer = (state = intitalState, action) => {
  switch (action.type) {
    case "SHOW_TOAST":
      return {
        ...state,
        toastInfo: action.payload,
      };
    default:
      return { ...state };
  }
};

export default toastReducer;
