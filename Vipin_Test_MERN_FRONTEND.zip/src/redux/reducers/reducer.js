const initialState = { data: [] };

const saveReducer = (state = initialState, action) => {
  switch (action.type) {
    case "ALL":
      return {
        ...state,
        data: action.payload,
      };
    default:
      return { ...state };
  }
};

export { saveReducer };
