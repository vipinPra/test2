import { combineReducers } from "redux";
import { saveReducer } from "./reducers/reducer";
import loaderReducer from "./reducers/loaderReducer";
import toastReducer from "./reducers/toastReducer";

const rootReducer = combineReducers({
  saveReducer,
  loaderReducer,
  toastReducer,
});

export default rootReducer;
