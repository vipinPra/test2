export const isAuthenticated = () => {
    if (typeof window == "undefined") {
        return false;
    }
    if (localStorage.getItem("Token")) {
        return JSON.parse(localStorage.getItem("Token"));
    } else {
        return false;
    }
};

export const authenticate = (res, next) => {
    if (typeof window !== "undefined") {
        localStorage.setItem("name", JSON.stringify(res.data.name));
        localStorage.setItem("Token", JSON.stringify(res.data.token));
        next();
    }
};

export const logout = (next) => {
    if (typeof window !== "undefined") {
        localStorage.clear();
        next();
    }
};