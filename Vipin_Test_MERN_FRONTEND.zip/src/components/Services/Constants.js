export const BASE_URL = "http://144.91.80.25:1010/";
export const END_POINT = {
    SIGIN: "api/admin/login",
}
