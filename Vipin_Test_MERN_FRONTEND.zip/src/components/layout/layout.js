import React from "react";
import Navbar from "../Navbar/navbar";
import Footer from "../Footer/footer";
import "./layout.css";

const Layout = ({ children }) => {
  return (
    <>
      <Navbar />
      <div className="wrapper">{children}</div>
      <Footer />
    </>
  );
};

export default Layout;
