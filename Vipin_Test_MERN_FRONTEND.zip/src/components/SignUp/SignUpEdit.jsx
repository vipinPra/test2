import React from "react";
import CustomCard from "../../Shared/Inputs/CustomCard";
import SignupForm from "./SignupForm";

const SignUpEdit = () => {
  return (
    <div>
      <CustomCard title="Edit Employee">
        <SignupForm />
      </CustomCard>
    </div>
  );
};

export default SignUpEdit;
