import React from "react";
import TableData from "../../Shared/TableData";
import SignUpConatiner from "./SignUpContainer";
import { ConfirmPopup, confirmPopup } from "primereact/confirmpopup";

const Signup = () => {
  const { data, columns } = SignUpConatiner();
  return (
    <>
      <ConfirmPopup />
      <TableData
        data={data}
        columns={columns}
        paginator
        rows={5}
        Title="All Employees"
        buttonTitle="Add Employee"
        linkTo="/add-employee"
      />
    </>
  );
};

export default Signup;
