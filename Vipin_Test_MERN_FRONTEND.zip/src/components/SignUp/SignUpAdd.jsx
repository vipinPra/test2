import React from "react";
import CustomCard from "../../Shared/Inputs/CustomCard";
import SignupForm from "./SignupForm";

const SignUpAdd = () => {
  return (
    <div>
      <CustomCard title="Add Employee">
        <SignupForm />
      </CustomCard>
    </div>
  );
};

export default SignUpAdd;
