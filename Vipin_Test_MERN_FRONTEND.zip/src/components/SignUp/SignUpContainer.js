import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import {
  deleteAction,
  getAllAction,
  saveAction,
} from "../../redux/actions/action";
import { ConfirmPopup, confirmPopup } from "primereact/confirmpopup";

const SignUpConatiner = () => {
  const data = useSelector((state) => state.saveReducer.data);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const deleteMain = (id) => {
    dispatch(deleteAction(id));
  };

  const deleteFunc = (e, id) => {
    confirmPopup({
      target: e.currentTarget,
      message:
        "Are you sure you want to delete this user? This action will permanently delete the user account. This action cannot be undone.",
      icon: "pi pi-exclamation-triangle",
      accept: () => deleteMain(id),
      reject: () => {},
    });
  };

  const actionTemplate = (col, rowIndex) => {
    return (
      <>
        <div className="flex justify-content-start">
          <span onClick={() => navigate(`/edit-employee/${col?._id}`)}>
            <i className="pi pi-pencil mr-3 cursor-pointer"></i>
          </span>
          <span onClick={(e) => deleteFunc(e, col?._id)}>
            <i className="pi pi-trash cursor-pointer"></i>
          </span>
        </div>
      </>
    );
  };

  const dateTemplate = (col) => {
    return (
      <div>
        {col?.dob?.length > 0 ? new Date(col?.dob).toLocaleDateString() : "--"}
      </div>
    );
  };

  const joiningTemplate = (col) => {
    return (
      <div>
        {col?.joiningDate?.length > 0
          ? new Date(col?.joiningDate).toLocaleDateString()
          : "--"}
      </div>
    );
  };

  const RelievingTemplate = (col) => {
    return (
      <div>
        {col?.relievingDate?.length > 0
          ? new Date(col?.relievingDate).toLocaleDateString()
          : "--"}
      </div>
    );
  };

  const StatusTemplate = (col) => {
    return (
      <div>
        {col?.status ? (col?.status == true ? "Active" : "Inactive") : "--"}
      </div>
    );
  };

  const salaryTemplate = (col) => {
    return <div>{col?.salary ? col?.salary : "--"}</div>;
  };

  const contactTemplate = (col) => {
    return <div>{col?.contact ? col?.contact : "--"}</div>;
  };

  const columns = [
    {
      field: "name",
      header: "Name",
    },
    {
      field: "dob",
      header: "Date of Birth",
      body: dateTemplate,
    },
    {
      field: "salary",
      header: "Salary",
      body: salaryTemplate,
    },
    {
      field: "joiningDate",
      header: "Joining Date",
      body: joiningTemplate,
    },
    {
      field: "relievingDate",
      header: "Relieving Date",
      body: RelievingTemplate,
    },
    {
      field: "contact",
      header: "Contact",
      body: contactTemplate,
    },
    {
      field: "status",
      header: "Status",
      body: StatusTemplate,
    },
    {
      field: "",
      header: "Action",
      body: actionTemplate,
      action: true,
    },
  ];

  useEffect(() => {
    dispatch(getAllAction());
  }, []);

  return {
    data,
    columns,
  };
};

export default SignUpConatiner;
