import React, { useRef } from "react";
import {
  CustomCalenderInput,
  CustomDropDown,
  CustomForm,
  CustomInput,
} from "../../Shared/Inputs/AllInputs";
import SingupFormContainer from "./SingupFormContainer";
import PrimaryButton from "../../Shared/Button/PrimaryButton";
import { Toast } from "primereact/toast";

const SignupForm = () => {
  const {
    signUpData,
    handleChangeSignUp,
    cancelSignUp,
    onSubmit,
    toast,
    statusOption,
  } = SingupFormContainer();
  return (
    <CustomForm>
      <Toast ref={toast} />
      <CustomInput
        label="Name"
        name="name"
        value={signUpData?.name}
        data={signUpData}
        onChange={handleChangeSignUp}
      />
      <CustomCalenderInput
        label="Date of Birth"
        name="dob"
        value={signUpData?.dob?.length > 0 ? new Date(signUpData?.dob) : null}
        data={signUpData}
        onChange={handleChangeSignUp}
      />
      <CustomInput
        label="Salary"
        name="salary"
        keyfilter="num"
        value={signUpData?.salary}
        data={signUpData}
        onChange={handleChangeSignUp}
      />
      <CustomCalenderInput
        label="Joining Date"
        name="joiningDate"
        value={
          signUpData?.joiningDate?.length > 0
            ? new Date(signUpData?.joiningDate)
            : null
        }
        data={signUpData}
        onChange={handleChangeSignUp}
      />

      <CustomCalenderInput
        label="Relieving Date"
        name="relievingDate"
        value={
          signUpData?.relievingDate?.length > 0
            ? new Date(signUpData?.relievingDate)
            : null
        }
        data={signUpData}
        onChange={handleChangeSignUp}
      />

      <CustomInput
        label="Contact"
        name="contact"
        keyfilter="num"
        value={signUpData?.contact}
        data={signUpData}
        onChange={handleChangeSignUp}
      />

      <CustomDropDown
        label="Status"
        name="status"
        value={signUpData?.status}
        data={signUpData}
        options={statusOption}
        onChange={handleChangeSignUp}
      />

      <div className="col-12 flex justify-content-end align-items-center">
        <PrimaryButton
          label="Save"
          onClick={onSubmit}
          col={6}
          style={{ width: "max-content" }}
        />
        <PrimaryButton
          label="Cancel"
          onClick={cancelSignUp}
          col={6}
          style={{ width: "max-content" }}
        />
      </div>
    </CustomForm>
  );
};

export default SignupForm;
