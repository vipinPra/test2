import React, { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";
import {
  getOneAction,
  saveAction,
  updateAction,
} from "../../redux/actions/action";
import { allValidations } from "../utils/formValidations";
import { showFormErrors } from "../utils/commonFunctions";

const SingupFormContainer = () => {
  const { id } = useParams();
  const toast = useRef(null);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [signUpData, setSignUpData] = useState({
    name: "",
    salary: "",
    joiningDate: "",
    relievingDate: "",
    dob: "",
    contact: "",
    status: null,
  });

  const [required, setRequired] = useState(["name"]);
  const [initialState, setInitialState] = useState({});

  const handleChangeSignUp = ({ name, value }) => {
    const formErrors = allValidations(
      name,
      value,
      signUpData,
      required,
      initialState
    );
    setSignUpData((prev) => {
      return {
        ...prev,
        [name]: value,
        formErrors,
      };
    });
  };

  const cancelSignUp = () => {
    setSignUpData({
      name: "",
      salary: "",
      joiningDate: "",
      relievingDate: "",
      dob: "",
      contact: "",
      status: null,
      education: [],
      experience: [],
    });

    navigate("/");
  };

  const onSubmit = () => {
    if (showFormErrors(signUpData, setSignUpData, required, initialState)) {
      if (id) {
        dispatch(updateAction(id, signUpData, navigate));
      } else {
        dispatch(saveAction(signUpData, navigate));
      }
    } else {
      window.scrollTo({
        top: 0,
        left: 0,
        behavior: "smooth",
      });
      toast.current.show({
        severity: "error",
        summary: "Error",
        detail: "Please Fill All Required Fields",
      });
    }
  };

  let statusOption = [
    { label: "Active", value: true },
    { label: "Inactive", value: false },
  ];

  useEffect(() => {
    if (id) {
      dispatch(
        getOneAction(id, (data) => {
          setSignUpData({
            name: data?.name,
            salary: data?.salary,
            joiningDate: data?.joiningDate,
            relievingDate: data?.relievingDate,
            dob: data?.dob,
            contact: data?.contact,
            status: data?.status,
          });
        })
      );
    }
    setInitialState(signUpData);
  }, [id]);

  return {
    signUpData,
    handleChangeSignUp,
    cancelSignUp,
    onSubmit,
    toast,
    statusOption,
  };
};

export default SingupFormContainer;
