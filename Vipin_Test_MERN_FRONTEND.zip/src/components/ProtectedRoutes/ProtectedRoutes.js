import React from 'react'
import { Route, Navigate } from "react-router-dom";
import { isAuthenticated } from '../Services/Auth';


const ProtectedRoutes = ({children}) => {
    const AuthenticateRoutes = () => {
    return isAuthenticated() ? children : <Navigate to="/" replace/>
    }
  return (
    <div>{AuthenticateRoutes()}</div>
  )
}

export default ProtectedRoutes