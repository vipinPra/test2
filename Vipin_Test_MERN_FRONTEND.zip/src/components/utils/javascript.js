export const equal = (obj1, obj2 = 0) => obj1 === obj2;

export const notEqual = (obj1, obj2) => !equal(obj1, obj2);

export const length = (obj) => obj.length;

export const values = (obj) => Object.values(obj);

export const entries = (obj) => Object.entries(obj);
