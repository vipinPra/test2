import { entries, notEqual, values } from "./javascript";
import { allValidations } from "./formValidations";

export const showFormErrors = (data, setData, required, initialData) => {
  let formErrors = {};
  entries(data).forEach(([key, value]) => {
    formErrors = {
      ...formErrors,
      ...allValidations(key, value, data, required, initialData),
    };
  });
  setData({ ...data, formErrors });
  let bolean = true;
  values(formErrors).map((item) => {
    if (bolean == false) {
      return;
    }
    if (typeof item === "object") {
      if (Array.isArray(item)) {
        if (item.length != 0) {
          bolean = false;
          return;
        } else {
          bolean = true;
        }
      } else {
        if (item == null) {
          bolean = true;
        } else if (!values(item).some((v) => notEqual(v, ""))) {
          bolean = true;
        } else {
          bolean = false;
          return;
        }
      }
    } else {
      if (item.length == 0) {
        bolean = true;
      } else {
        bolean = false;
        return;
      }
    }
  });
  return bolean;
};

export const removeEmpty = (obj) => {
  const newObj = {};
  Object.entries(obj).forEach(([k, v]) => {
    if (v === Object(v)) {
      newObj[k] = removeEmpty(v);
    } else if (v !== "" && v !== null) {
      newObj[k] = obj[k];
    }
  });
  return newObj;
};
