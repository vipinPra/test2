import React from "react";
import "./footer.css";

const Footer = () => {
  return (
    <div className="footer">
      <h6>All Right Reserved © 2024</h6>
    </div>
  );
};

export default Footer;
