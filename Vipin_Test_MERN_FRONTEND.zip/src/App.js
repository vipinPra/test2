import React, { Suspense, lazy } from "react";
import "./App.css";
import "./assests/fonts/RACING_HARD.ttf";
// import "./styles.scss";
import { Routes, Route } from "react-router-dom";
import Signup from "./components/SignUp/Signup";
import Layout from "./components/layout/layout";
import SignUpAdd from "./components/SignUp/SignUpAdd";
import SignUpEdit from "./components/SignUp/SignUpEdit";
import Loader from "./components/loader/loader";
import ToastContainer from "./components/toast/toast";

function App() {
  return (
    <Layout>
      <Loader />
      <ToastContainer />
      <Routes>
        <Route path="/" exact element={<Signup />} />
        <Route path="/add-employee" exact element={<SignUpAdd />} />
        <Route path="/edit-employee/:id" exact element={<SignUpEdit />} />
      </Routes>
    </Layout>
  );
}

export default App;
