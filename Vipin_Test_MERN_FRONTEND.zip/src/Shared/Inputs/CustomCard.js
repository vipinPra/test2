import { useNavigate } from "react-router-dom";
import PrimaryButton from "../Button/PrimaryButton";

export default function CustomCard({
  title,
  children,
  className,
  backable = true,
  buttonTitle,
  linkTo,
  extraClassName,
  ...props
}) {
  const navigate = useNavigate();
  return (
    <div className={`label-table ${className}`}>
      <div className="surface-300 py-3 px-3 flex justify-content-between w-full m-0">
        <div className="flex justify-content-start align-items-center">
          <i
            className="pi pi-angle-left text-2xl my-auto cursor-pointer"
            onClick={() => navigate(-1)}
          />
          <div className=" my-auto" style={{ fontSize: "20px" }}>
            {title}
          </div>
        </div>
      </div>
      <div className="p-2  border border-1 border-300 p-fluid">{children}</div>
    </div>
  );
}
