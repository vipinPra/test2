import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import PrimaryButton from "./Button/PrimaryButton";
import { useNavigate } from "react-router-dom";

const TableData = ({
  data,
  columns,
  selectionMode,
  delRow,
  selected,
  changeSelection,
  key,
  checked,
  rows,
  paginator,
  filters,
  editMode,
  onRowEditComplete,
  editingRows,
  Title,
  buttonTitle,
  linkTo,
  extraClassName,
  style,
}) => {
  const navigate = useNavigate();
  const dynamicColumns = columns.map((col, i) => {
    return (
      <Column
        key={col.field}
        field={col.field}
        sortable={col.sorting ? true : false}
        header={col.header}
        hidden={col.hidden ? col.hidden : false}
        body={col.body ? eval(col.body) : null}
        editor={col.editor ? eval(col.editor) : null}
        style={
          col.action
            ? { width: "60px" }
            : { paddingLeft: " 50px", paddingRight: "50px" }
        }
      />
    );
  });

  console.log("data", data);

  return (
    <div>
      <div className=" border-round-xl">
        <div>
          <div className="flex justify-content-between py-2 px-3">
            <div style={{ fontSize: "20px" }}>{Title ? Title : null}</div>
            <div>
              {buttonTitle ? (
                <PrimaryButton
                  severity="secondary"
                  className="mt-2 md:mt-0 border-round-l"
                  onClick={() => navigate(linkTo)}
                  label={buttonTitle}
                  extraClassName={extraClassName}
                />
              ) : null}
            </div>
          </div>
          <DataTable
            value={data}
            paginator={paginator ? true : false}
            filters={filters ? filters : null}
            rows={rows ? rows : null}
            selectionMode={!selectionMode ? false : "checkbox"}
            delRow={delRow}
            selection={selected ? selected : null}
            onSelectionChange={changeSelection ? changeSelection : null}
            dataKey={key}
            checked={checked}
            editMode={editMode}
            onRowEditComplete={onRowEditComplete ? onRowEditComplete : null}
            editingRows={editingRows ? editingRows : null}
          >
            {dynamicColumns}
          </DataTable>
        </div>
      </div>
    </div>
  );
};
export default TableData;
