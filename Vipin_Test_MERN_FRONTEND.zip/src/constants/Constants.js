export const Base_url = "http://localhost:2020/api/";
export const End_point = {
  employee: "employee/",
};
